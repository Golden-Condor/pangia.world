module.exports = {
    "ceramic-dispenser": "6819472a8b9147531693ef55",
    "cooler-rental": "6819472f8b9147531693ef56",
    "jug-exchange": "681947338b9147531693ef57",
    "manual-pump": "681947378b9147531693ef58",
    "single-5-gallon": "6819473b8b9147531693ef59",
    "starter-pack": "6819473f8b9147531693ef5a",
    "20oz-case-24pack": "681fc194fe944aaa58b31e1b"
  };
